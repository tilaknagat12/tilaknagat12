/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>

using namespace std;

int main()
{
    int n;
    cout<<"Enter the year : ";
    cin>>n;
    
    if ((n%4)==0)
    {
        cout<<"this is leap year.";
    }
    else
    {
        cout<<"not leap year."; 
    }
    return 0;
    
}
